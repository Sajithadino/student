<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->date('dob');
        $table->string('gender');
        $table->string('mobile_number');
        $table->string('email')->unique();
        $table->unsignedBigInteger('country_id');
        $table->unsignedBigInteger('state_id');
        $table->foreign('country_id')->references('id')->on('countries');
        $table->foreign('state_id')->references('id')->on('states');
        $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
