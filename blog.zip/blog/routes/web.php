<?php


use Illuminate\Support\Facades\Route;

use App\Http\Controllers\StudenttController;
use App\Http\Controllers\MarkController;
use App\Http\Controllers\SupplierController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

    Route::group(['middleware' => ['auth']], function () {
    Route::post('/login', 'LoginController@login')->name('login');
    Route::get('/', 'StudentController@index');
    Route::get('/students/create', 'StudentController@create');
    Route::post('/students/store', 'StudentController@store');
    Route::get('/students/edit/{id}', 'StudentController@edit');
    Route::post('/students/update/{id}', 'StudentController@update');
    Route::get('/students/delete/{id}', 'StudentController@destroy');
    Route::get('/marks', 'MarkController@create')->name('marks.create');
    Route::post('/marks', 'MarkController@store')->name('marks.store');
    Route::get('/student-marks', 'MarkController@index')->name('marks.index');


});

Auth::routes();
