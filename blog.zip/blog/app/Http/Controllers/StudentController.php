<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
class StudentController extends Controller
{
    //
    public function destroy($id)
{
    $student = Student::find($id);

    if($student){
        $student->delete();
        return redirect('/students')->with('success', 'Student deleted successfully');
    }else{
        return redirect('/students')->with('error', 'Student not found');
    }
}

}
