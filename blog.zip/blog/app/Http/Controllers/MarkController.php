<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MarkController extends Controller
{
    //

    public function create()
{
    $students = Student::all();
    return view('marks.create', compact('students'));
}





public function store(Request $request)
{
    $validatedData = $request->validate([
        'student_id' => 'required',
        'term' => 'required',
        'subject' => 'required',
        'marks' => 'required|numeric|min:0|max:100'
    ]);

    $mark = new Mark;
    $mark->student_id = $request->input('student_id');
    $mark->term = $request->input('term');
    $mark->subject = $request->input('subject');
    $mark->marks = $request->input('marks');
    $mark->save();

    return redirect('/marks')->with('success', 'Mark added successfully');
}

public function index()
{
    $marks = Mark::with('student')->get();
    return view('marks.index', compact('marks'));
}


}
