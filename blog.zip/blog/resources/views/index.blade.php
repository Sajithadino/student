@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">{{ __('Students List') }}</div>

                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>DOB</th>
                                    <th>Gender</th>
                                    <th>Mobile Number</th>
                                    <th>Email</th>
                                    <th>Country</th>
                                    <th>State</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($students as $student)
                                    <tr>
                                        <td>{{ $student->id }}</td>
                                        <td>{{ $student->name }}</td>
                                        <td>{{ $student->dob }}</td>
                                        <td>{{ $student->gender }}</td>
                                        <td>{{ $student->mobile_number }}</td>
                                        <td>{{ $student->email }}</td>
                                        <td>{{ $student->country->name }}</td>
                                        <td>{{ $student->state->name }}</td>
                                        <td>
                                            <a href="{{ url('/students/edit/'.$student->id) }}" class="btn btn-primary">Edit</a>
                                            <a href="{{ url('/students/delete/'.$student->id) }}" class="btn btn-danger">Delete</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
